public class Division extends BinaryExpression {
    public Division(Expression left, Expression right) {
        super(left, right);
    }

    @Override
    public String toString() {
        return "(" + left.toString() + "/" + right.toString() + ")";
    }

    @Override
    public double evaluate() throws ArithmeticException {
        try {
            return (int) left.evaluate() / (int) right.evaluate();
        } catch (ArithmeticException e) {
            System.out.println("Lỗi chia cho 0");
            return 0;
        }

    }

    public static void main(String[] args) {
        Expression left = new Numeral(3);
        Expression right = new Numeral(0);
        Division div = new Division(left, right);
        System.out.println(div.evaluate());
    }
}
