import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Week11 {
        public static <T> List<T> sortGeneric(List<T> arr) {
        if (arr instanceof Person) {
            Collections.sort(arr, new Comparator<T>() {
                @Override
                public int compare(T o1, T o2) {
                    if (o1 instanceof Person && o2 instanceof Person) {
                        Person x = (Person) o1;
                        Person y = (Person) o2;

                        int com = x.getName().compareTo(y.getName());
                        if (com > 0) return +1;
                        else if (com < 0) return -1;

                        if (x.getAge() > y.getAge()) return -1;
                        else if (x.getAge() < y.getAge()) return +1;
                        else return 0;
                    }
                    return 0;
                }
            });
        }
        else Collections.sort(arr, null);
        return arr;
    }
}
